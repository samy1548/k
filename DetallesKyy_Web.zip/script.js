
function verMas() {
  window.scrollTo({
    top: document.querySelector(".productos").offsetTop - 50,
    behavior: "smooth"
  });
}
